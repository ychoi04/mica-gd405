function setup() {
	createCanvas(400, 400, SVG); // add a third parameter, SVG.
}

function draw() {
	clear(); // do not remove this line.
	
	/* add your own code below. */
	
	background(200);
	for (var i = 0; i < width; i+=10) {
		line(0, i, i, 0);
	}

}

// press s key to save SVG.
function keyTyped() {
	if (key === 's') {
		save();
	}
}