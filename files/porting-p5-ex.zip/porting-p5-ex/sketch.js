var x;
var y;
var xmargin = 20;
var ymargin = 20;

var slant = 0;
var inc = 0;

function setup() {
	createCanvas(600, 600);
	background(240);
	noFill();
	
	x = xmargin;
	y = ymargin;
}


function draw() {
	//  background(240);

}

function keyTyped() {
	if (key == "a") {
		drawA(x, y, slant, false);
		x += 60;
	} else if (key == "b") {
		drawB(x, y, slant, false);
		x += 60;
	} else if (key == "c") {
		drawC(x, y, slant, false);
		x += 60;
	} else if (key == " ") {
		x += 60;
	}

	if (x > width - 60) {
		x = xmargin;
		y += 100;
	}
	
	slant = sin(inc)*50;
	inc += 0.2;
}

function drawA(x, y, sl, round) {
	push();
	translate(x, y);
	beginShape();
  if (round) curveVertex(10+sl*4/8,50);
	vertex(10+sl*4/8,50);
	vertex(20+sl*5/8,40);
	vertex(50+sl*5/8,40);
	vertex(50+sl*3/8,60);
	vertex(50,90);
	vertex(10,90);
	vertex(10+sl*2/8,70);
	vertex(20+sl*3/8,60);
	vertex(50+sl*3/8,60);
	if (round) curveVertex(50+sl*3/8,60);
	endShape();
	line(60-sl*1/8, 100, 50, 90);
	pop();
}

function drawB(x, y, sl, round) {
	push();
	translate(x, y);
	beginShape();
	if (round) curveVertex(10+sl,10);
	vertex(10+sl,10);
	vertex(10+sl*5/8,40);
	vertex(10+sl*1/8,80);
	vertex(20,90);
	vertex(50,90);
	vertex(50+sl*4/8,50);
	vertex(40+sl*5/8,40);
	vertex(10+sl*5/8,40);
	if (round) curveVertex(10+sl*5/8,40);
	endShape();
	pop();
}

function drawC(x, y, sl, round) {
	push();
	translate(x, y);
	beginShape();
	if (round) curveVertex(50+sl*4/8,50);
	vertex(50+sl*4/8,50);
	vertex(40+sl*5/8,40);
	vertex(20+sl*5/8,40);
	vertex(10+sl*4/8,50);
	vertex(10+sl*1/8,80);
	vertex(20,90);
	vertex(40,90);
	vertex(50+sl*1/8,80);
	if (round) curveVertex(50+sl*1/8,80);
	endShape();
	pop();
}